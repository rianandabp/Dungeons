﻿using GXPEngine;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;

/**
 * An example of a dungeon nodegraph implementation.
 * 
 * This implementation places only three nodes and only works with the SampleDungeon.
 * Your implementation has to do better :).
 * 
 * It is recommended to subclass this class instead of NodeGraph so that you already 
 * have access to the helper methods such as getRoomCenter etc.l 
 * 
 * TODO:
 * - Create a subclass of this class, and override the generate method, see the generate method below for an example.
 */
 class LowLevelDungeonNodeGraph : NodeGraph
{
	protected Dungeon _dungeon;
	Dictionary<KeyValuePair<int, int>, Boolean> wall = new Dictionary<KeyValuePair<int, int>, bool>();
	public LowLevelDungeonNodeGraph(Dungeon pDungeon) : base((int)(pDungeon.size.Width * pDungeon.scale), (int)(pDungeon.size.Height * pDungeon.scale), (int)pDungeon.scale/3)
	{
		Debug.Assert(pDungeon != null, "Please pass in a dungeon.");

		_dungeon = pDungeon;
		addWall(pDungeon);
	}

	protected override void generate ()
	{

		

		
	}

	void BFS( Dungeon pDungeon)
    {
		Boolean[,] visited = new Boolean[(int)(pDungeon.size.Width * pDungeon.scale), (int)(pDungeon.size.Height * pDungeon.scale)];
		Queue<KeyValuePair<int, int>> queue = new Queue<KeyValuePair<int, int>>();

		nodes.Add(new Node(getPointCenter(new Point(1, 1))));
		queue.Enqueue(new KeyValuePair<int, int>(1, 1));
		visited[1, 1] = true;

        while (queue.Count != 0)
        {
			int x = queue.Peek().Key;
			int y = queue.Peek().Value;

			if(!wall.ContainsKey(new KeyValuePair<int, int>(x - 1, y)))
            {
				nodes.Add(new Node(getPointCenter(new Point(x-1, y))));

			}
        }
    }
	void addWall(Dungeon pDungeon)
    {
		int roomCnt = _dungeon.rooms.Count;
		int doorCnt = _dungeon.doors.Count;

		for (int a = 0; a < roomCnt; a++)
		{
			//for each room node added, add connection with the doors node available (door on that room)

			int roomLeft = _dungeon.rooms[a].area.Left;
			int roomRight = _dungeon.rooms[a].area.Right;
			int roomTop = _dungeon.rooms[a].area.Top;
			int roomBottom = _dungeon.rooms[a].area.Bottom;

			for (int i = roomLeft; i <= roomRight - 1; i++) wall.Add(new KeyValuePair<int, int>(i, roomTop),true);
			for (int i = roomLeft; i <= roomRight - 1; i++) wall.Add(new KeyValuePair<int, int>(i, roomBottom), true);
			for (int i = roomTop; i <= roomBottom - 1; i++) wall.Add(new KeyValuePair<int, int>(i, roomLeft), true);
			for (int i = roomTop; i <= roomBottom - 1; i++) wall.Add(new KeyValuePair<int, int>(i, roomRight), true);


		}

		for (int b = 0; b < doorCnt; b++)
		{
			int doorX = _dungeon.doors[b].location.X;
			int doorY = _dungeon.doors[b].location.Y;
			if (wall.ContainsKey(new KeyValuePair<int, int>(doorX, doorY))) wall.Remove(new KeyValuePair<int, int>(doorX, doorY));
		}
	}
	/**
	 * A helper method for your convenience so you don't have to meddle with coordinate transformations.
	 * @return the location of the center of the given room you can use for your nodes in this class
	 */

	protected Point getRoomCenter(Room pRoom)
	{
		float centerX = ((pRoom.area.Left + pRoom.area.Right) / 2.0f) * _dungeon.scale;
		float centerY = ((pRoom.area.Top + pRoom.area.Bottom) / 2.0f) * _dungeon.scale;
		return new Point((int)centerX, (int)centerY);
	}

	/**
	 * A helper method for your convenience so you don't have to meddle with coordinate transformations.
	 * @return the location of the center of the given door you can use for your nodes in this class
	 */
	protected Point getDoorCenter(Door pDoor)
	{
		return getPointCenter(pDoor.location);
	}

	/**
	 * A helper method for your convenience so you don't have to meddle with coordinate transformations.
	 * @return the location of the center of the given point you can use for your nodes in this class
	 */
	protected Point getPointCenter(Point pLocation)
	{
		float centerX = (pLocation.X + 0.5f) * _dungeon.scale;
		float centerY = (pLocation.Y + 0.5f) * _dungeon.scale;
		return new Point((int)centerX, (int)centerY);
	}

}
