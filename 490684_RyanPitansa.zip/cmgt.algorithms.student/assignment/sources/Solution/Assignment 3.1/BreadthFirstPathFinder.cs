﻿using GXPEngine;
using System;
using System.Collections.Generic;


class BreadthFirstPathFinder : PathFinder	{

    Dictionary<Node, Node> pred = new Dictionary<Node, Node>();
    Dictionary<Node, int> dist = new Dictionary<Node, int>();
    List<Node> result = new List<Node>();

    public BreadthFirstPathFinder(NodeGraph pGraph) : base(pGraph) {}

	protected override List<Node> generate(Node pFrom, Node pTo)
	{

        //result must be clear so it will not overlap with previous path result
        result.Clear();

        BFS(pFrom, pTo, pred, dist);
        

        return GetResult(pTo);
    }

    
    List<Node> GetResult(Node pTo)
    {
        Node crawl = pTo;
        result.Add(pTo);

        for (int a = 0; a < dist[pTo]; a++)
        {
            result.Add(pred[crawl]);
            crawl = pred[crawl];
        }

        result.Reverse();
        return result;
    }

    bool BFS(Node pFrom, Node pTo,
         Dictionary<Node, Node> pred, Dictionary<Node, int> dist)
    {
        Queue<Node> queue = new Queue<Node>();

        Dictionary<Node, Boolean> visited = new Dictionary<Node, Boolean>();

        visited.Add(pFrom, true);
        dist.Add(pFrom, 0);
        queue.Enqueue(pFrom);

        while (queue.Count!=0)
        {
            Console.WriteLine(queue.Peek());
            Node u = queue.Peek();
            queue.Dequeue();
            foreach (var item in u.connections)
            {
                if (!visited.ContainsKey(item))
                {
                    visited.Add(item, true);
                    dist[item] = dist[u] + 1;
                    pred.Add(item, u);
                    queue.Enqueue(item);

                    if (item == pTo)
                        return true;
                }
            }
        }

        return false;
    }

}

