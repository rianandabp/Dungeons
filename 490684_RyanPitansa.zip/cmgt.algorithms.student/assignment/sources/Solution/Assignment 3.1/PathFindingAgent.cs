﻿using GXPEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

class PathFindingAgent : NodeGraphAgent
{
	private Node _current = null;
	private Node _target = null;
	private PathFinder pFinder = null;
	List<Node> path = null;
	public PathFindingAgent(NodeGraph pNodeGraph, PathFinder pPathFinder) : base(pNodeGraph)
	{
		SetOrigin(width / 2, height / 2);

		//position ourselves on a random node
		if (pNodeGraph.nodes.Count > 0)
		{
			//set random node to current node
			_current = pNodeGraph.nodes[Utils.Random(0, pNodeGraph.nodes.Count)];
			jumpToNode(_current);
		}

		//listen to nodeclicks
		pNodeGraph.OnNodeLeftClicked += onNodeClickHandler;
		pFinder = pPathFinder;

	}

	protected virtual void onNodeClickHandler(Node pNode)
	{
		//generate path to the target
		_target = pNode;
		path = pFinder.Generate(_current, _target);
	}

	protected override void Update()
	{
		//no target? Don't walk
		//there is no connection from the current node? Don't walk
		if (path != null && path.Count!=0)
		{
			//Move towards the target node, if we reached it, clear the target
			if (moveTowardsNode(path.First()))
			{
				//if we reached it, set current node as target.
				_current = path.First();
				path.RemoveAt(0);
				if(path.Count == 0)pFinder.graphics.Clear(Color.Transparent);
			}
		}

		else if (path != null && path.Count != 0 && !_current.connections.Contains(path.First())) path.RemoveAt(0);

		return;
	}
}