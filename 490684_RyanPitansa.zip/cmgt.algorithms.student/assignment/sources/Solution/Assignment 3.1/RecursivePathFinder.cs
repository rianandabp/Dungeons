﻿using GXPEngine;
using System;
using System.Collections.Generic;

class RecursivePathFinder : PathFinder	{

	
	static Queue<Node> temp = new Queue<Node>();
	Dictionary<Node, Boolean> visited = new Dictionary<Node, Boolean>();
	List<Node> currentPath = new List<Node>();
	List<Node> result = new List<Node>();

	RecursivePathFinder(NodeGraph pGraph) : base(pGraph) { }

	protected override List<Node> generate(Node pFrom, Node pTo)
	{
		temp.Clear();
		visited.Clear();
		currentPath.Clear();
		result.Clear();

		currentPath.Add(pFrom);
		visited.Add(pFrom, true);

		search(currentPath, visited, pFrom, pTo);

		foreach (var item in temp) result.Add(item);

		if (result.Count != 0)
		{
			Console.WriteLine("Yes path found!!");
			return result;
		}
		else 
		{ 
			Console.WriteLine("Too bad, no path found !!");
			return null;
		}
		

	}

	public static void search(List<Node> currentPath, Dictionary<Node, Boolean> visited, Node pFrom, Node pTo)
	{
		if (pFrom == pTo)
		{
			//if current path equal target, put the current path on temporary queue
			if (temp.Count == 0) foreach (var item in currentPath) temp.Enqueue(item);
			else
			{
				//if the algorithm found shorter path than current path, update the result
				if (currentPath.Count < temp.Count)
				{
					temp.Clear();
					foreach (var item in currentPath) temp.Enqueue(item);
				}

			}
			return;
		}

		foreach (var item in pFrom.connections)
		{
			if (!visited.ContainsKey(item))
			{
				currentPath.Add(item);
				visited.Add(item, true);
	
				search(currentPath, visited, item, pTo); //search it recursively
				
				//backtracking the algorithm
				visited.Remove(item);
				currentPath.RemoveAt(currentPath.Count - 1);
			}
		}
		return;
	}

}

