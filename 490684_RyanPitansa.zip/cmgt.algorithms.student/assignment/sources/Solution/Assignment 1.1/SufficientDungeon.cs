﻿using GXPEngine;
using System.Drawing;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Collections.Generic;



class SufficientDungeon : Dungeon
{

	public SufficientDungeon(Size pSize) : base(pSize) { }

	protected override void generate(int pMinimumRoomSize)
	{
		//2D array for record line that intersect between two rooms
		int[,] roomIntersection = new int[size.Width + 1, size.Height + 1];

		Split(0, 0, size.Width, size.Height, pMinimumRoomSize, 0, roomIntersection);
		draw();
	}

	//recursive function that split rooms
	void Split(int x, int y, int width, int height, int minSize, int cnt, int[,] roomIntersection)
	{
		//split it with vertical line
		if (cnt % 2 == 0)
		{
			//because the coordinate start from 0 but we count the total width
			//start from 1, so anything related to the coordinate will be added with + 1

			int leftWall = x + minSize;
			int rightWall = (width + x - minSize);

			//the base case, when room can't be split into more smaller one,
			//add room into the list

			if (leftWall >= rightWall)
			{
				rooms.Add(new Room(new Rectangle(x, y,  width, height)));
				return;
			}

			//random the width of the room that bigger than minimum size
			int temp = Utils.Random(leftWall, rightWall);

			//create the left room
			Split(x, y, temp + 1 - x, height, minSize, cnt + 1, roomIntersection);

			//create the right room
			Split(temp, y, width + x - temp, height, minSize, cnt + 1, roomIntersection);

			//record the coordinate of each corner of the room
			//so, door can be placed in the correct place (not intersect with the wall)

			//LEFT ROOM
			roomIntersection[x, y]++;					//left, top
			roomIntersection[x, y + height - 1]++;		//left, bottom
			roomIntersection[temp, y]++;				//right, top
			roomIntersection[temp, y + height - 1]++;	//right, bottom

			//RIGHT ROOM
			roomIntersection[temp, y]++;						//left, top
			roomIntersection[temp, y + height - 1]++;			//left, bottom
			roomIntersection[width + x - 1, y]++;				//right, top
			roomIntersection[width + x - 1, y + height - 1]++;	//right, bottom

			//the coordinate range for placing the door randomly
			int x1 = temp, y1 = y, y2 = y + height - 1;

			//keep random the location until its location do not intersect with other lines.
			int rand;
			do
			{
				rand = Utils.Random(y1, y2);
			} while (roomIntersection[x1, rand] != 0);

			doors.Add(new Door(new Point(x1, rand)));
		}
		//split it with horizontal line
		else
		{
			//everything same with vertical line except for the coordinate

			int leftWall = y + minSize;
			int rightWall = (height + y - minSize);

			if (leftWall >= rightWall)
			{
				rooms.Add(new Room(new Rectangle(x, y, width, height)));
				return;
			}
			int temp = Utils.Random(leftWall, rightWall);

			Split(x, y, width, temp + 1 - y, minSize, cnt + 1, roomIntersection);
			Split(x, temp, width, height + y - temp, minSize, cnt + 1, roomIntersection);

			roomIntersection[x, y]++;
			roomIntersection[x + width - 1, y]++;
			roomIntersection[x, temp]++;
			roomIntersection[x + width - 1, temp]++;

			roomIntersection[x, temp]++;
			roomIntersection[x + width - 1, temp]++;
			roomIntersection[x, height + y - 1]++;
			roomIntersection[x + width - 1, height + y - 1]++;

			int y1 = temp, x1 = x, x2 = x + width - 1;
			int rand;

			do
			{
				rand = Utils.Random(x1, x2);
			} while (roomIntersection[rand, y1] != 0);
			doors.Add(new Door(new Point(rand, y1)));
		}
	}
}

