﻿using GXPEngine;
using System.Drawing;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.CodeDom.Compiler;
using System.Linq;

class ExcellentDungeon : Dungeon
{

	public ExcellentDungeon(Size pSize) : base(pSize) { }

	protected override void generate(int pMinimumRoomSize)
	{
		int[,] roomIntersection = new int[size.Width + 1, size.Height + 1];

		Split(0, 0, size.Width, size.Height, pMinimumRoomSize, 0, roomIntersection);
		DecreaseRoomSize();
		draw();
	}

	//recursive function that split rooms
	void Split(int x, int y, int width, int height, int minSize, int cnt, int[,] roomIntersection)
	{
		if (cnt % 2 == 0)
		{

			int leftWall = x + minSize;
			int rightWall = (width + x - minSize);

			if (leftWall >= rightWall)
			{
				rooms.Add(new Room(new Rectangle(x, y,  width, height)));
				return;
			}

			int temp = Utils.Random(x + minSize + 1, (width + x + 1 - minSize));

			Split(x, y, temp + 1 - x, height, minSize, cnt + 1, roomIntersection);
			Split(temp, y, width + x - temp, height, minSize, cnt + 1, roomIntersection);

			roomIntersection[x, y]++;
			roomIntersection[x, y + height - 1]++;
			roomIntersection[temp, y]++;
			roomIntersection[temp, y + height - 1]++;

			roomIntersection[temp, y]++;
			roomIntersection[temp, y + height - 1]++;
			roomIntersection[width + x - 1, y]++;
			roomIntersection[width + x - 1, y + height - 1]++;

			int x1 = temp, y1 = y, y2 = y + height - 1;

			int rand;
			do
			{
				rand = Utils.Random(y1, y2);

			} while (roomIntersection[x1, rand] != 0);

			doors.Add(new Door(new Point(x1, rand)));
		}
		else
		{
			int leftWall = y + minSize;
			int rightWall = (height + y - minSize);

			if (leftWall >= rightWall)
			{
				rooms.Add(new Room(new Rectangle(x, y, width, height)));
				return;
			}
			int temp = Utils.Random(y + minSize + 1, (height + y + 1 - minSize));

			Split(x, y, width, temp + 1 - y, minSize, cnt + 1, roomIntersection);
			Split(x, temp, width, height + y - temp, minSize, cnt + 1, roomIntersection);

			roomIntersection[x, y]++;
			roomIntersection[x + width - 1, y]++;
			roomIntersection[x, temp]++;
			roomIntersection[x + width - 1, temp]++;

			roomIntersection[x, temp]++;
			roomIntersection[x + width - 1, temp]++;
			roomIntersection[x, height + y - 1]++;
			roomIntersection[x + width - 1, height + y - 1]++;

			int y1 = temp, x1 = x, x2 = x + width - 1;
			int rand;

			do
			{
				rand = Utils.Random(x1, x2);
			} while (roomIntersection[rand, y1] != 0);
			doors.Add(new Door(new Point(rand, y1)));
		}
	}

	void DecreaseRoomSize()
    {
		//set the boundary for decrease the size and search where the door placed in the room
		foreach (var item in rooms.ToList())
        {
			int roomTop = item.area.Top;
			int roomBottom = item.area.Bottom;
			int roomLeft = item.area.Left;
			int roomRight = item.area.Right;

			//these should not decrease the room size more than or equal half than its original size
			int min_x = (roomRight - roomLeft) / 2 + roomLeft;
			int max_x = roomRight - (roomRight - roomLeft) / 2;

			int min_y = (roomBottom - roomTop) / 2 + roomTop;
			int max_y = roomBottom - (roomBottom - roomTop) / 2;

			//list of doors in the room
			List<KeyValuePair<int,int>> door = new List<KeyValuePair<int,int>>();

			foreach (var item2 in doors)
            {
				int doorX = item2.location.X;
				int doorY = item2.location.Y;

				//check the top wall
				if (doorX > roomLeft && doorX < roomRight && doorY == roomTop)
				{
					door.Add(new KeyValuePair<int, int>(doorX, doorY));
					if (doorX < min_x) min_x = doorX - 1;
					if (doorX > max_x) max_x = doorX + 1;
				}

				//check bottom wall
				if (doorX > roomLeft && doorX < roomRight && doorY == roomBottom - 1)
				{
					door.Add(new KeyValuePair<int, int>(doorX, doorY));
					if (doorX < min_x) min_x = doorX - 1;
					if (doorX > max_x) max_x = doorX + 1;
				}

				//check left wall
				if (doorY > roomTop && doorY < roomBottom && doorX == roomLeft)
				{
					door.Add(new KeyValuePair<int, int>(doorX, doorY));
					if (doorY < min_y) min_y = doorY - 1;
					if (doorY > max_y) max_y = doorY + 1;
				}

				//check right wall
				if (doorY > roomTop && doorY < roomBottom && doorX == roomRight - 1)
				{
					door.Add(new KeyValuePair<int, int>(doorX, doorY));
					if (doorY < min_y) min_y = doorY - 1;
					if (doorY > max_y) max_y = doorY + 1;
				}

				
			}

			//increase left wall size
			int rand = Utils.Random(roomLeft, min_x);

			int x = -1;
			int y = -1;

			//to check if there is door on the wall
			foreach (var element in door)
			{
				if (element.Value > roomTop && element.Value < roomBottom && element.Key == roomLeft)
				{
					x = element.Key;
					y = element.Value;
					break;
				}

			}

			for (int a = roomLeft; a < rand; a++) 
			{
				//if there is door, then add the door (create hallway) simultaneously within the new wall
				if (x != -1) doors.Add(new Door(new Point(a, y)));
				rooms.Add(new Room(new Rectangle(a, roomTop, 1, roomBottom - roomTop)));
			}
				
			//increase right wall size
			rand = Utils.Random(max_x, roomRight);

			x = -1;
			y = -1;
			foreach (var element in door)
			{
				if (element.Value > roomTop && element.Value < roomBottom && element.Key == roomRight - 1)
				{
					x = element.Key;
					y = element.Value;
					break;
				}
			}

			for (int a = roomRight - 1; a > rand; a--)
            {
				if (x != -1) doors.Add(new Door(new Point(a, y)));
				rooms.Add(new Room(new Rectangle(a, roomTop, 1, roomBottom - roomTop)));
			}
				

			//increase top wall size
			rand = Utils.Random(roomTop, min_y);
			Console.WriteLine(rand);
			x = -1;
			y = -1;
			foreach (var element in door)
			{
				if (element.Key > roomLeft && element.Key < roomRight && element.Value == roomTop)
				{
					x = element.Key;
					y = element.Value;
					break;
				}
			}

			for (int a = roomTop; a < rand; a++)
            {
				if (x != -1) doors.Add(new Door(new Point(x, a)));
				rooms.Add(new Room(new Rectangle(roomLeft, a, roomRight - roomLeft, 1)));
			}
				
			//increase bottom wall size
			rand = Utils.Random(max_y, roomBottom);

			x = -1;
			y = -1;

			foreach (var element in door)
			{
				if (element.Key > roomLeft && element.Key < roomRight && element.Value == roomBottom - 1)
				{
					x = element.Key;
					y = element.Value;
					break;
				}
			}

			for (int a = roomBottom - 1; a > rand; a--)
            {
				if (x != -1) doors.Add(new Door(new Point(x, a)));
				rooms.Add(new Room(new Rectangle(roomLeft, a, roomRight - roomLeft, 1)));
			}

			door.Clear();

		}

    }

}

