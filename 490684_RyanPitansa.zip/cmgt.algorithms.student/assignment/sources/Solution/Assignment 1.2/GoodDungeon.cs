﻿using GXPEngine;
using System.Drawing;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Collections.Generic;



class GoodDungeon : Dungeon
{
	private static Random random = new Random(10);
	private static int maxRoomSize, minRoomSize;
	public GoodDungeon(Size pSize) : base(pSize) {}


	protected override void generate(int pMinimumRoomSize)
	{
		int[,] roomIntersection = new int[size.Width+1, size.Height+1];

		maxRoomSize = 0;
		minRoomSize = size.Width * size.Height;

		Split(0, 0, size.Width, size.Height, pMinimumRoomSize, 0, roomIntersection);
		RemoveRoom();
		draw();
	}

	void Split(int x, int y, int width, int height, int minSize, int cnt, int [,] roomIntersection)
	{
		if (cnt % 2 == 0)
		{

			int leftWall = x + minSize;
			int rightWall = (width + x - minSize);


			if (leftWall >= rightWall)
			{
				rooms.Add(new Room(new Rectangle(x, y, width, height)));
				//update min and max room size everytime adding a new room into the list
				maxRoomSize = Math.Max(maxRoomSize, width * height);
				minRoomSize = Math.Min(minRoomSize, width * height);
				return;
			}

			int temp = random.Next(leftWall, rightWall);

			
			Split(x, y, temp + 1 - x, height, minSize, cnt + 1, roomIntersection);
			
			Split(temp, y, width + x - temp, height, minSize, cnt + 1, roomIntersection);

			roomIntersection[x, y]++; 
			roomIntersection[x, y + height - 1]++; 
			roomIntersection[temp, y]++; 
			roomIntersection[temp, y + height - 1]++; 

			roomIntersection[temp, y]++; 
			roomIntersection[temp, y + height - 1]++; 
			roomIntersection[width + x - 1, y]++; 
			roomIntersection[width + x - 1, y + height - 1]++; 

			int x1 = temp, y1 = y, y2 = y + height - 1;

			
			int rand;
			do
			{
				rand = Utils.Random(y1, y2);
			} while (roomIntersection[x1, rand] != 0);

			doors.Add(new Door(new Point(x1, rand)));
		}
		else
		{

			int leftWall = y + minSize;
			int rightWall = (height + y - minSize);

			if (leftWall >= rightWall)
			{
				rooms.Add(new Room(new Rectangle(x, y, width, height)));
				//update min and max room size everytime adding a new room into the list
				maxRoomSize = Math.Max(maxRoomSize, width * height);
				minRoomSize = Math.Min(minRoomSize, width * height);
				return;
			}

			int temp = Utils.Random(leftWall, rightWall);

			Split(x, y, width, temp + 1 - y, minSize, cnt + 1, roomIntersection);
			Split(x, temp, width, height + y - temp, minSize, cnt + 1, roomIntersection);

			roomIntersection[x, y]++;
			roomIntersection[x + width - 1, y]++;
			roomIntersection[x, temp]++;
			roomIntersection[x + width - 1, temp]++;

			roomIntersection[x, temp]++;
			roomIntersection[x + width - 1, temp]++;
			roomIntersection[x, height + y - 1]++;
			roomIntersection[x + width - 1, height + y - 1]++;

			int y1 = temp, x1 = x, x2 = x + width - 1;
			int rand;

			do
			{
				rand = Utils.Random(x1, x2);
			} while (roomIntersection[rand, y1] != 0);
			doors.Add(new Door(new Point(rand, y1)));
		}
	}


	//Remove room that equal to min and max size
	protected void RemoveRoom()
    {
		int roomCnt = rooms.Count;

		for(int a = 0; a < roomCnt; a++)
        {
			int area = rooms[a].area.Width * rooms[a].area.Height;
			if (area == maxRoomSize || area == minRoomSize)
            {
				RemoveDoor(rooms[a].area.Left, rooms[a].area.Right, rooms[a].area.Top, rooms[a].area.Bottom);
				rooms.RemoveAt(a);
				RemoveRoom();
				return;
            }
        }
    }

	//Remove door that belongs to certain room
	protected void RemoveDoor(int roomLeft, int roomRight, int roomTop, int roomBottom)
    {
		
		int doorCnt = doors.Count;

		for(int a = 0; a < doorCnt; a++)
        {

			int doorX = doors[a].location.X;
			int doorY = doors[a].location.Y;

			//check door on the top wall
			if (doorX > roomLeft && doorX < roomRight && doorY == roomTop)
			{
				doors.RemoveAt(a);
				RemoveDoor(roomLeft, roomRight, roomTop, roomBottom);
				return;
			}
			//check door on the left wall
			if (doorY > roomTop && doorY < roomBottom && doorX == roomLeft)
			{
				doors.RemoveAt(a);
				RemoveDoor(roomLeft, roomRight, roomTop, roomBottom);
				return;
			}
			//check door on the bottom wall
			if (doorX > roomLeft && doorX < roomRight && doorY == roomBottom - 1)
			{
				doors.RemoveAt(a);
				RemoveDoor(roomLeft, roomRight, roomTop, roomBottom);
				return;
			}
			//check door on the right wall
			if (doorY > roomTop && doorY < roomBottom && doorX == roomRight - 1)
			{
				doors.RemoveAt(a);
				RemoveDoor(roomLeft, roomRight, roomTop, roomBottom);
				return;
			}
		}

		return;
    }

	//draw room on specific color based on how many doors in it
	protected override void drawRooms(IEnumerable<Room> pRooms, Pen pWallColor, Brush pFillColor = null)
    {
		
		foreach (Room room in pRooms)
		{
			int doors = CountDoors(room.area.Left, room.area.Right, room.area.Top, room.area.Bottom);
			if (doors == 0) drawRoom(room, pWallColor, Brushes.Red);
			else if (doors == 1) drawRoom(room, pWallColor, Brushes.Orange);
			else if (doors == 2) drawRoom(room, pWallColor, Brushes.Yellow);
			else drawRoom(room, pWallColor, Brushes.Green);
		}
	}

	//function to count how many doors in single room
	protected int CountDoors(int roomLeft, int roomRight, int roomTop, int roomBottom)
	{

		int cnt = 0;
		int doorCnt = doors.Count;

		for (int a = 0; a < doorCnt; a++)
		{

			int doorX = doors[a].location.X;
			int doorY = doors[a].location.Y;

			//check door on the top wall
			if (doorX > roomLeft && doorX < roomRight && doorY == roomTop) cnt++;
		
			//check door on the left wall
			if (doorY > roomTop && doorY < roomBottom && doorX == roomLeft) cnt++;

			//check door on the bottom wall
			if (doorX > roomLeft && doorX < roomRight && doorY == roomBottom - 1) cnt++;

			//check door on the right wall
			if (doorY > roomTop && doorY < roomBottom && doorX == roomRight - 1) cnt++;

		}
		return cnt;
	}
}

