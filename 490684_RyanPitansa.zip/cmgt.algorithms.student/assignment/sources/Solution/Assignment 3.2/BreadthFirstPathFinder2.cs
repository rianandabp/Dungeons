﻿using GXPEngine;
using System;
using System.Collections.Generic;

/**
 * An example of a PathFinder implementation which completes the process by rolling a die 
 * and just returning the straight-as-the-crow-flies path if you roll a 6 ;). 
 */
class BreadthFirstPathFinder2 : PathFinder	
{

    
    List<Node> nodes = new List<Node>();
    
    Dictionary<KeyValuePair<Node, Node>, double> graph = new Dictionary<KeyValuePair<Node, Node>, double>();
    Dictionary<Node, Node> pred = new Dictionary<Node, Node>();
    List<Node> result = new List<Node>();
   
    public BreadthFirstPathFinder2(NodeGraph pGraph) : base(pGraph) 
    {
        //copy the nodes into new list
        nodes.AddRange(pGraph.nodes);
    }

	protected override List<Node> generate(Node pFrom, Node pTo)
	{
        //because node can be disable, the connections may be changed
        //therefore, the algorithm must be run everythime the node has been disable/enable

        result.Clear();
        graph.Clear();
        setDistance();
        pred.Clear();
      
        dijkstra(pFrom);

        //if no path found return null
        if (!pred.ContainsKey(pTo)) return null;

        return getResult(pFrom, pTo);
        
    }

    List<Node> getResult(Node pFrom, Node pTo)
    {
        Node crawl = pTo;
        result.Add(pTo);

        do
        {
            result.Add(pred[crawl]);
            crawl = pred[crawl];
        } while (crawl != pFrom);

        result.Reverse();

        return result;
    }

    //For debug purpose
    //Print the distance between each node
    /*
    void printSolution(Dictionary<Node, double> dist)
    {
        foreach (var item in dist)
        {
            Console.WriteLine(item);
        }
    }*/


    void setDistance()
    {
        int vertices = nodes.Count;
        for(int a = 0; a < vertices; a++)
        {
            foreach(var item in nodes[a].connections)
            {
                int x1 = nodes[a].location.X;
                int y1 = nodes[a].location.Y;
                int x2 = item.location.X;
                int y2 = item.location.Y;
                graph.Add(new KeyValuePair<Node, Node>(nodes[a], item), calcDistance(x1, y1, x2, y2));
            }
        }
    }

    //Search minimum distance for each node
    Node minDistance(Dictionary<Node, double> dist, Dictionary<Node, Boolean> sptSet)
    {
        // Initialize min value 
        double min = Int32.MaxValue;
        Node min_index = null;

        foreach (var item in nodes)
            if (sptSet[item] == false && dist[item] <= min)
            {
                min = dist[item];
                min_index = item;
            }
                

        return min_index;
    }

    void dijkstra(Node src)
    {
        Dictionary<Node,double> dist = new Dictionary<Node, double>(); 
        Dictionary<Node,Boolean> sptSet = new Dictionary<Node, Boolean>();

        dist.Clear();
        sptSet.Clear();

        foreach (var item in nodes)
        {
            dist.Add(item, Int32.MaxValue);
            sptSet.Add(item, false);
        }

        dist[src] = 0;

        int V = nodes.Count;
        for (int count = 0; count < V - 1; count++)
        {
            Node u = minDistance(dist, sptSet);

            sptSet[u] = true;

            foreach (var item in nodes)
            {
                if (!sptSet[item] && graph.ContainsKey(new KeyValuePair<Node, Node>(u, item)) && dist[u] != Int32.MaxValue
                  && dist[u] + graph[new KeyValuePair<Node, Node>(u, item)] < dist[item])
                {
                    dist[item] = dist[u] + graph[new KeyValuePair<Node, Node>(u, item)];
                    pred.Add(item, u);
                }
            }

           
        }

    }

    double calcDistance(double x1, double y1, double x2, double y2)
    {
        return Math.Sqrt(Math.Pow(x2 - x1, 2) +
                Math.Pow(y2 - y1, 2) * 1.0);
    }
    

}

