﻿using GXPEngine;
using System;
using System.Collections;
using System.Collections.Generic;


class OffGraphWayPointAgent : NodeGraphAgent
{
	//current target to move towards
	private Queue<Node> _target = new Queue<Node>();
	//current node where agent located
	private Node _current = null;
	public OffGraphWayPointAgent(NodeGraph pNodeGraph) : base(pNodeGraph)
	{
		SetOrigin(width / 2, height / 2);

		//position ourselves on a random node
		if (pNodeGraph.nodes.Count > 0)
		{
			//set random node to current node
			_current = pNodeGraph.nodes[Utils.Random(0, pNodeGraph.nodes.Count)];
			jumpToNode(_current);
		}

		//listen to nodeclicks
		pNodeGraph.OnNodeLeftClicked += onNodeClickHandler;
	}

	protected virtual void onNodeClickHandler(Node pNode)
	{
		//insert target to the queue
		_target.Enqueue(pNode);
	}

	protected override void Update()
	{

		//no target? Don't walk
		//there is no connection from the current node? Don't walk
		if(_target.Count != 0 && _current.connections.Contains(_target.Peek()))
        {
			//Move towards the target node, if we reached it, clear the target
			if (moveTowardsNode(_target.Peek()))
			{
				//if we reached it, set current node as target.
				_current = _target.Peek();
				_target.Dequeue();
			}
        }

		//if there is no connection between the node in the queue and current node, remove the node
		//in the queue
		if (_target.Count != 0 && !_current.connections.Contains(_target.Peek())) _target.Dequeue();

		return;
	}
}
