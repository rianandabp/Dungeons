﻿using GXPEngine;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;


 class HighLevelDungeonNodeGraph : NodeGraph
{
	protected Dungeon _dungeon;

	public HighLevelDungeonNodeGraph(Dungeon pDungeon) : base((int)(pDungeon.size.Width * pDungeon.scale), (int)(pDungeon.size.Height * pDungeon.scale), (int)pDungeon.scale/3)
	{
		Debug.Assert(pDungeon != null, "Please pass in a dungeon.");
		_dungeon = pDungeon;
	}

	protected override void generate ()
	{

		int roomCnt = _dungeon.rooms.Count;
		int doorCnt = _dungeon.doors.Count;

		for(int a = 0; a< doorCnt; a++) nodes.Add(new Node(getDoorCenter(_dungeon.doors[a])));
    

		for(int a = 0; a < roomCnt; a++)
        {
			nodes.Add(new Node(getRoomCenter(_dungeon.rooms[a])));

			//for each room node added, add connection with the door nodes on that room
			for(int b = 0; b < doorCnt; b++)
            {

				double doorX = _dungeon.doors[b].location.X;
				double doorY = _dungeon.doors[b].location.Y;
				double roomLeft = _dungeon.rooms[a].area.Left;
				double roomRight = _dungeon.rooms[a].area.Right;
				double roomTop = _dungeon.rooms[a].area.Top;
				double roomBottom = _dungeon.rooms[a].area.Bottom;


				//check door on the top wall
				if (doorX > roomLeft && doorX < roomRight && doorY==roomTop)
					AddConnection(nodes[b], nodes[doorCnt + a]);

				//check door on the left wall
				else if (doorY > roomTop && doorY < roomBottom && doorX==roomLeft )
					AddConnection(nodes[b], nodes[doorCnt + a]);

				//check door on the bottom wall
				else if (doorX > roomLeft && doorX < roomRight && doorY == roomBottom-1)
					AddConnection(nodes[b], nodes[doorCnt + a]);

				//check door on the right wall
				else if (doorY > roomTop && doorY < roomBottom && doorX == roomRight-1)
					AddConnection(nodes[b], nodes[doorCnt + a]);

			}

		}

		
	}

	/**
	 * A helper method for your convenience so you don't have to meddle with coordinate transformations.
	 * @return the location of the center of the given room you can use for your nodes in this class
	 */

	protected Point getRoomCenter(Room pRoom)
	{
		float centerX = ((pRoom.area.Left + pRoom.area.Right) / 2.0f) * _dungeon.scale;
		float centerY = ((pRoom.area.Top + pRoom.area.Bottom) / 2.0f) * _dungeon.scale;
		return new Point((int)centerX, (int)centerY);
	}

	/**
	 * A helper method for your convenience so you don't have to meddle with coordinate transformations.
	 * @return the location of the center of the given door you can use for your nodes in this class
	 */
	protected Point getDoorCenter(Door pDoor)
	{
		return getPointCenter(pDoor.location);
	}

	/**
	 * A helper method for your convenience so you don't have to meddle with coordinate transformations.
	 * @return the location of the center of the given point you can use for your nodes in this class
	 */
	protected Point getPointCenter(Point pLocation)
	{
		float centerX = (pLocation.X + 0.5f) * _dungeon.scale;
		float centerY = (pLocation.Y + 0.5f) * _dungeon.scale;
		return new Point((int)centerX, (int)centerY);
	}

}
