﻿using GXPEngine;
using System;

class OnGraphWayPointAgent : NodeGraphAgent
{
	private Node _target = null;
	private Node _current = null;
	private Node _previous = null;

	Boolean up = true;
	int rand;
	public OnGraphWayPointAgent(NodeGraph pNodeGraph) : base(pNodeGraph)
	{
		SetOrigin(width / 2, height / 2);

		//position ourselves on a random node
		if (pNodeGraph.nodes.Count > 0)
		{
			_current = pNodeGraph.nodes[Utils.Random(0, pNodeGraph.nodes.Count)];
			_previous = _current;
			jumpToNode(_current);
		}

		//listen to nodeclicks
		pNodeGraph.OnNodeLeftClicked += onNodeClickHandler;
	}

	protected virtual void onNodeClickHandler(Node pNode)
	{
		//if morc still walking, don't listen to click
		if(_target == null) _target = pNode;
	}

	protected override void Update()
	{
		//no target? Don't walk
		if (_target == null) return;

		//if morc reach the target, set target to null
        if (_current == _target)
        {
			_target = null;
			return;
        }
		
		int size = _current.connections.Count;

		//if morc can reach it's destination from the current position, do it.
		for (int a = 0; a < size; a++)
		{
			if (_current.connections[a] == _target)
			{
				if (moveTowardsNode(_current.connections[a]))
                {
					_previous = _current;
					_current = _target;
				}
				return;
			}
		}


		//random the way where morch will move.
		//it's only update if random value equal to previous node and morc has reached the target.
		if (up) 
		{
			rand = Utils.Random(0, size);
			if (_current.connections[rand] == _previous && _current.connections.Count != 1) return;
			up = false;
		}
		
		//morc move to the target and update current node and previous node when it reached the target.
        if (moveTowardsNode(_current.connections[rand]))
        {
			up = true;
			_previous = _current;
			_current = _current.connections[rand];
        }
		

	}
}
