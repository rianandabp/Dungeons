﻿using GXPEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

class TiledDungeonView : TiledView
{

	List<Room> temp = new List<Room>();
	Boolean[,] doors;

	public TiledDungeonView(Dungeon pDungeon, TileType pDefaultTileType) : base(pDungeon.size.Width, pDungeon.size.Height, (int)pDungeon.scale, pDefaultTileType)
	{
		//copy rooms in dungeon into temporary list
		temp.AddRange(pDungeon.rooms.ToList());

		doors = new Boolean[pDungeon.size.Width, pDungeon.size.Height];
		PinPointDoor(pDungeon.doors);	
		
	}

	void PinPointDoor(List<Door> pDoor)
    {
		//pinpoint where the door coordinate on the map
		foreach (var item in pDoor)
		{
			doors[item.location.X, item.location.Y] = true;
		}
	}

	protected override void generate()
	{

		foreach (var item in temp)
        {
			int roomTop = item.area.Top;
			int roomRight = item.area.Right;
			int roomLeft = item.area.Left;
			int roomBottom = item.area.Bottom;

			for(int a = roomLeft; a < roomRight; a++)
            {
				for(int b = roomTop; b < roomBottom; b++)
                {
					//create wall except for the door located
					if ((a == roomLeft || a == roomRight-1 || b == roomTop || b == roomBottom-1) && !doors[a, b])
						SetTileType(a, b, TileType.WALL);
                }
            }

        }

	}
}

