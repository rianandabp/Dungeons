﻿using GXPEngine;
using System.Drawing;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.InteropServices;
using System.Collections.Generic;


/**
 * An example of a dungeon implementation.  
 * This implementation places two rooms manually but your implementation has to do it procedurally.
 */
class SampleDungeon : Dungeon
{
	
	public SampleDungeon(Size pSize) : base(pSize) {}

	/**
	 * This method overrides the super class generate method to implement a two-room dungeon with a single door.
	 * The good news is, it's big enough to house an Ogre and his ugly children, the bad news your implementation
	 * should generate the dungeon procedurally, respecting the pMinimumRoomSize.
	 * 
	 * Hints/tips: 
	 * - start by generating random rooms in your own Dungeon class and placing random doors.
	 * - playing/experiment freely is the key to all success
	 * - this problem can be solved both iteratively or recursively
	 */
	protected override void generate(int pMinimumRoomSize)
	{
		//left room from 0 to half of screen + 1 (so that the walls overlap with the right room)
		//(TODO: experiment with removing the +1 below to see what happens with the walls)
		//rooms.Add(new Room(new Rectangle(8, 0, 24, 11)));
		//rooms.Add(new Room(new Rectangle(8, 0, 17, 11)));
		//rooms.Add(new Room(new Rectangle(24, 0, 8, 11)));
		//rooms.Add(new Room(new Rectangle(12, 7, 14, 13)));
		//rooms.Add(new Room(new Rectangle(0, 0, 7, 5)));
		//rooms.Add(new Room(new Rectangle(6, 0, 5, 5)));

		//right room from half of screen to the end
		rooms.Add(new Room(new Rectangle(0, 0, size.Width/2+1, size.Height)));
		rooms.Add(new Room(new Rectangle(size.Width/2, 0, size.Width/2, size.Height)));
		
		//and a door in the middle wall with a random y position
		//TODO:experiment with changing the location and the Pens.White below
		doors.Add(new Door(new Point(size.Width/2, size.Height / 2 + Utils.Random(-5, 5))));

        /*int[,] array = new int[size.Width + 1, size.Height + 1];
        void generatee(int x, int y, int width, int height, int minSize, int cnt)
        {
            rooms.Add(new Room(new Rectangle(x, y, width, height)));
            Console.Write(x);
            Console.Write(" ");
            Console.Write(y);
            Console.Write(" ");
            Console.Write(width);
            Console.Write(" ");
            Console.Write(height);
            Console.Write(" ");
            Console.WriteLine(cnt);
            if (cnt % 2 == 0)
            {
                Console.WriteLine("Vertical");
                if (x + minSize + 1 >= (width - minSize)) return;
                int temp = Utils.Random(x + minSize + 1, (width - minSize));
                generatee(x, y, temp + 1, height, minSize, cnt + 1);
                generatee(temp + x, y, width - temp, height, minSize, cnt + 1);

                array[x, y]++;
                array[x, y + height - 1]++;
                array[temp + x, y]++;
                array[temp + x, y + height - 1]++; 

           Console.Write(temp);
           Console.Write(" ");
           Console.WriteLine(y);
           Console.Write(temp);
           Console.Write(" ");
           Console.WriteLine(y + height);

           array[temp + x, y]++;
           array[temp + x, y + height - 1]++;
           array[width - 1, y]++;
           array[width - 1, y + height - 1]++;

           Console.WriteLine("x,y " + array[x, y]);
           Console.WriteLine("x, y + height " + array[x, y + height - 1]);
           Console.WriteLine("temp + x, y " + array[temp + x, y]);
           Console.WriteLine("temp + x, y + height " + array[temp + x, y + height - 1]);

           int x1 = temp + x, y1 = y, y2 = y + height - 1;
                if (array[x, y] == 2 && y1 == -1) { y1 = y; x1 = temp + x; }
                else if(array[x, y] == 2 && y1 != -1) y2 = y;

                if (array[x, y + height - 1] == 2 && y1 == -1) { y1 = y + height - 1; x1 = temp + x; }
                else if(array[x, y + height - 1] == 2 && y1 != -1) y2 = y + height - 1;

                if (array[temp + x, y] == 2 && y1 == -1) { y1 = y; x1 = temp + x; }
                else if(array[temp + x, y] == 2 && y1 != -1) y2 = y;

                if (array[temp + x, y + height - 1] == 2 && y1 == -1) { y1 = y + height - 1; x1 = temp + x; }
                else if(array[temp + x, y + height - 1] == 2 && y1 != -1) y2 = y + height - 1;

                if (y1 > y2)
                {
                    int swap = 0;
                    swap = y1;
                    y1 = y2;
                    y2 = swap;
                }
                do
                {
                    Console.WriteLine("yes");
                    Console.WriteLine(x1);
                    Console.WriteLine(y1);
                    Console.WriteLine(y2);
                    temp = Utils.Random(y1, y2);
                } while (array[x1,temp] != 0);
                doors.Add(new Door(new Point(x1, temp)));
            }
            else
            {
                Console.WriteLine("Horizontal");
                if (y + minSize + 1 >= (height - minSize)) return;
                int temp = Utils.Random(y + minSize + 1, (height - minSize));
                generatee(x, y, width, temp+1, minSize, cnt + 1);
                generatee(x, temp + y, width, height-temp, minSize, cnt + 1);

                array[x, y]++;
                array[x + width - 1, y]++;
                array[x, y + temp]++;
                array[x + width - 1, y + temp]++;

                array[x, y + temp]++;
                array[x + width - 1, y + temp]++;
                array[x, height - 1]++;
                array[x + width - 1, height - 1]++;

                int y1 = temp + y, x1 = x, x2 = x + width - 1;
                do
                {
                    Console.WriteLine("hehe");
                    Console.WriteLine(y1);
                    Console.WriteLine(x1);
                    Console.WriteLine(x2);
                    temp = Utils.Random(x1, x2);
                } while (array[temp, y1] != 0);
                doors.Add(new Door(new Point(temp, y1)));
            }
        }


                generatee(0, 0, size.Width, size.Height, pMinimumRoomSize, 0);
        array[0, 0]++;
        Console.WriteLine(array[0, 0]);
        Console.Write(size.Width);
        Console.WriteLine(size.Height);*/
        draw();
    }
}

